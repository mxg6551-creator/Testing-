import React from 'react';
import { ShieldAlert } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const AgeGateModal: React.FC = () => {
  const { isAgeGatePassed, setIsAgeGatePassed, siteSettings } = useApp();

  if (isAgeGatePassed || !siteSettings.ageGateEnabled) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl">
      <div className="relative w-full max-w-md bg-[#12141e] rounded-2xl border border-red-900/50 p-6 sm:p-8 text-center shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-200">
        <div className="w-16 h-16 mx-auto rounded-full bg-red-600/20 border border-red-500/50 flex items-center justify-center text-red-500 shadow-lg">
          <ShieldAlert className="w-9 h-9" />
        </div>

        <div>
          <span className="text-2xl font-black text-red-500 bg-red-950/80 border border-red-800/80 px-2 py-0.5 rounded">
            18+ ONLY
          </span>
          <h2 className="text-lg sm:text-xl font-bold text-white mt-3">
            Age Verification Warning
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
            This website is intended strictly for adults (18+ or the age of majority in your jurisdiction). It contains adult and mature themes.
          </p>
        </div>

        <div className="p-3 bg-[#191c2b] rounded-xl text-[11px] text-slate-400 border border-slate-800 text-left">
          By clicking <strong>&quot;I am 18 or older&quot;</strong>, you certify that you are of legal adult age to view such content in your region and agree to our Terms of Use.
        </div>

        <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
          <button
            onClick={() => setIsAgeGatePassed(true)}
            className="flex-1 py-3 px-4 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-extrabold text-xs sm:text-sm rounded-xl uppercase tracking-wider shadow-lg transition"
          >
            I am 18 or older (Enter)
          </button>
          <button
            onClick={() => {
              window.location.href = 'https://www.google.com';
            }}
            className="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs sm:text-sm rounded-xl transition"
          >
            Under 18 (Exit)
          </button>
        </div>
      </div>
    </div>
  );
};
