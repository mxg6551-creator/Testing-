import React, { useEffect } from 'react';
import { Menu, Search, Settings, ShieldCheck, Crown, User as UserIcon, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Header: React.FC = () => {
  const {
    siteSettings,
    searchQuery,
    setSearchQuery,
    setIsSidebarOpen,
    setIsSettingsModalOpen,
    setIsVipModalOpen,
    setIsAuthModalOpen,
    setIsAdminOpen,
    currentUser,
    isAdminLoggedIn,
    isNightMode,
    t,
  } = useApp();

  // Listen for secret admin search trigger or shortcut (Ctrl + Shift + A)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && (e.key === 'a' || e.key === 'A')) {
        e.preventDefault();
        setIsAdminOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [setIsAdminOpen]);

  // Handle typing /admin in search
  const handleSearchChange = (val: string) => {
    if (val.trim().toLowerCase() === '/admin' || val.trim().toLowerCase() === 'adminlogin') {
      setSearchQuery('');
      setIsAdminOpen(true);
      return;
    }
    setSearchQuery(val);
  };

  return (
    <header
      className={`sticky top-0 z-40 px-3 sm:px-6 py-2.5 border-b transition-colors ${
        isNightMode
          ? 'bg-[#0e1017]/95 backdrop-blur-md border-slate-800/80 text-white'
          : 'bg-white/95 backdrop-blur-md border-slate-200 text-slate-900 shadow-xs'
      }`}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-4">
        {/* Left: Hamburger & Logo */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setIsSidebarOpen(true)}
            aria-label="Open Navigation Menu"
            className={`p-1.5 rounded-lg transition ${
              isNightMode
                ? 'text-slate-300 hover:text-white hover:bg-slate-800'
                : 'text-slate-600 hover:text-black hover:bg-slate-100'
            }`}
          >
            <Menu className="w-6 h-6" />
          </button>

          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-1.5 select-none"
          >
            <span className="text-2xl sm:text-3xl font-extrabold tracking-tighter text-[#facc15] font-sans drop-shadow-sm">
              {siteSettings.siteLogoText || 'FUQ'}
            </span>
            <span className="text-xs font-bold text-red-500 uppercase tracking-wider bg-red-950/60 border border-red-800/50 px-1 py-0.5 rounded">
              18+
            </span>
          </a>
        </div>

        {/* Center: Search Bar */}
        <div className="flex-1 max-w-xl mx-1 sm:mx-4">
          <div className="relative flex items-center">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => handleSearchChange(e.target.value)}
              placeholder={t('searchPlaceholder')}
              className={`w-full text-sm rounded-lg pl-9 pr-9 py-2 border transition focus:outline-none focus:ring-1 focus:ring-[#facc15] ${
                isNightMode
                  ? 'bg-[#171923] text-slate-100 placeholder-slate-400 border-slate-700/80 focus:border-[#facc15]'
                  : 'bg-slate-100 text-slate-900 placeholder-slate-500 border-slate-300 focus:border-amber-500'
              }`}
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 p-1 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* VIP Upgrade Button */}
          <button
            onClick={() => setIsVipModalOpen(true)}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-bold text-amber-300 bg-gradient-to-r from-amber-600/30 to-yellow-500/20 border border-amber-500/40 hover:border-amber-400 hover:from-amber-600/40 transition shadow-sm"
          >
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            <span>{t('vipPass')}</span>
          </button>

          {/* Settings icon */}
          <button
            onClick={() => setIsSettingsModalOpen(true)}
            aria-label="Display Settings"
            className={`p-2 rounded-lg transition ${
              isNightMode
                ? 'text-slate-300 hover:text-white hover:bg-slate-800'
                : 'text-slate-600 hover:text-black hover:bg-slate-100'
            }`}
          >
            <Settings className="w-5 h-5" />
          </button>

          {/* Secret/Hidden Admin Indicator - ONLY visible when admin is logged in or owner triggers it */}
          {isAdminLoggedIn && (
            <button
              onClick={() => setIsAdminOpen(true)}
              title="Admin Control Panel"
              className="p-2 rounded-lg text-amber-400 bg-amber-950/40 border border-amber-500/50 hover:bg-amber-900/40 transition"
            >
              <ShieldCheck className="w-5 h-5" />
            </button>
          )}

          {/* User Profile / Login */}
          <button
            onClick={() => setIsAuthModalOpen(true)}
            className={`flex items-center gap-1.5 p-1 sm:px-2 sm:py-1 rounded-lg transition ${
              isNightMode
                ? 'text-slate-300 hover:text-white hover:bg-slate-800'
                : 'text-slate-700 hover:text-black hover:bg-slate-100'
            }`}
          >
            {currentUser?.avatar ? (
              <img
                src={currentUser.avatar}
                alt={currentUser.username}
                className="w-7 h-7 rounded-full border border-slate-700 object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              <UserIcon className="w-5 h-5" />
            )}
            <span className="text-xs font-medium hidden lg:inline max-w-[90px] truncate">
              {currentUser ? currentUser.username : t('signIn')}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
