import React, { useState } from 'react';
import {
  X,
  LayoutDashboard,
  FileVideo,
  PlusCircle,
  FolderTree,
  MessageSquare,
  DollarSign,
  Megaphone,
  Settings,
  Users,
  ShieldCheck,
  UserPlus,
  Link as LinkIcon,
  Trash2,
  Edit,
  CheckCircle,
  XCircle,
  Upload,
  LogOut,
  TrendingUp,
  Search,
  Lock,
  Crown,
  Key,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Video, User, SubAdmin, CustomSidebarLink } from '../../types';

export const AdminDashboard: React.FC = () => {
  const {
    isAdminOpen,
    setIsAdminOpen,
    isAdminLoggedIn,
    loggedInAdminRole,
    loginAdmin,
    logoutAdmin,
    videos,
    addVideo,
    updateVideo,
    deleteVideo,
    categories,
    addCategory,
    deleteCategory,
    comments,
    deleteComment,
    vipOrders,
    approveVipOrder,
    rejectVipOrder,
    vipPackages,
    updateVipPackagePrice,
    subAdmins,
    addSubAdmin,
    removeSubAdmin,
    customSidebarLinks,
    addCustomSidebarLink,
    deleteCustomSidebarLink,
    users,
    updateUserByAdmin,
    deleteUserByAdmin,
    stats,
    adSettings,
    updateAdSettings,
    siteSettings,
    updateSiteSettings,
    showToast,
  } = useApp();

  // Admin login credentials input
  const [adminUser, setAdminUser] = useState('');
  const [adminPass, setAdminPass] = useState('');

  // Active admin tab
  const [currentTab, setCurrentTab] = useState<
    'stats' | 'posts' | 'orders' | 'users' | 'subadmins' | 'links' | 'categories' | 'comments' | 'ads' | 'settings'
  >('stats');

  // Video editor modal state (includes Views, Likes, Dislikes modifications!)
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingVideoId, setEditingVideoId] = useState<string | null>(null);
  const [videoTitle, setVideoTitle] = useState('');
  const [videoDesc, setVideoDesc] = useState('');
  const [videoCategory, setVideoCategory] = useState('bangladeshi');
  const [videoTags, setVideoTags] = useState('');
  const [videoDuration, setVideoDuration] = useState('15:20');
  const [videoThumbnailUrl, setVideoThumbnailUrl] = useState('');
  const [videoEmbedCode, setVideoEmbedCode] = useState('');
  const [videoDownloadUrl, setVideoDownloadUrl] = useState('');
  const [videoIsVip, setVideoIsVip] = useState(false);
  const [videoQuality, setVideoQuality] = useState<'HD' | '4K' | 'SD'>('HD');
  const [videoViews, setVideoViews] = useState(1400);
  const [videoLikes, setVideoLikes] = useState(120);
  const [videoDislikes, setVideoDislikes] = useState(5);

  // User management states
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [editingUser, setEditingUser] = useState<User | null>(null);

  // Sub-admin form
  const [newSubName, setNewSubName] = useState('');
  const [newSubUsername, setNewSubUsername] = useState('');
  const [newSubEmail, setNewSubEmail] = useState('');
  const [newSubPassword, setNewSubPassword] = useState('');

  // Custom sidebar link form
  const [newLinkTitle, setNewLinkTitle] = useState('');
  const [newLinkUrl, setNewLinkUrl] = useState('');
  const [newLinkBadge, setNewLinkBadge] = useState('HOT');

  // Category form
  const [newCatName, setNewCatName] = useState('');
  const [newCatSlug, setNewCatSlug] = useState('');

  // Site settings form
  const [siteTitle, setSiteTitle] = useState(siteSettings.siteTitle);
  const [siteLogo, setSiteLogo] = useState(siteSettings.siteLogoText);
  const [adminUsernameInput, setAdminUsernameInput] = useState(siteSettings.adminUsername);
  const [adminPasswordInput, setAdminPasswordInput] = useState(siteSettings.adminPasswordHash);
  const [bkashNum, setBkashNum] = useState(siteSettings.bkashNumber);
  const [nagadNum, setNagadNum] = useState(siteSettings.nagadNumber);
  const [rocketNum, setRocketNum] = useState(siteSettings.rocketNumber);
  const [antiCopyToggle, setAntiCopyToggle] = useState(siteSettings.antiCopyEnabled);
  const [ageGateToggle, setAgeGateToggle] = useState(siteSettings.ageGateEnabled);

  // Ad settings
  const [topBannerHtml, setTopBannerHtml] = useState(adSettings.topBannerHtml);
  const [topBannerImg, setTopBannerImg] = useState(adSettings.topBannerImage);
  const [topBannerLink, setTopBannerLink] = useState(adSettings.topBannerLink);
  const [smartLink1, setSmartLink1] = useState(adSettings.smartLink1);
  const [smartLink2, setSmartLink2] = useState(adSettings.smartLink2);
  const [smartLink3, setSmartLink3] = useState(adSettings.smartLink3);
  const [directDownload, setDirectDownload] = useState(adSettings.directDownloadLink);

  if (!isAdminOpen) return null;

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const success = loginAdmin(adminUser, adminPass);
    if (success) {
      setAdminUser('');
      setAdminPass('');
    }
  };

  const handleCloseAdmin = () => {
    // Strict session security: Always logout admin when closing panel
    logoutAdmin();
    setIsAdminOpen(false);
  };

  const handleOpenNewPost = () => {
    setEditingVideoId(null);
    setVideoTitle('');
    setVideoDesc('');
    setVideoCategory(categories[1]?.slug || 'bangladeshi');
    setVideoTags('Viral, Desi, 1080p');
    setVideoDuration('14:30');
    setVideoThumbnailUrl('https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80');
    setVideoEmbedCode('<iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ" frameborder="0" allowfullscreen></iframe>');
    setVideoDownloadUrl('https://mega.nz/folder/mmshub-vault');
    setVideoIsVip(false);
    setVideoQuality('HD');
    setVideoViews(1200);
    setVideoLikes(95);
    setVideoDislikes(3);
    setIsEditorOpen(true);
  };

  const handleOpenEditPost = (video: Video) => {
    setEditingVideoId(video.id);
    setVideoTitle(video.title);
    setVideoDesc(video.description);
    setVideoCategory(video.category);
    setVideoTags(video.tags.join(', '));
    setVideoDuration(video.duration);
    setVideoThumbnailUrl(video.thumbnailUrl);
    setVideoEmbedCode(video.embedCode);
    setVideoDownloadUrl(video.downloadUrl || '');
    setVideoIsVip(video.isVip);
    setVideoQuality(video.quality || 'HD');
    setVideoViews(video.views);
    setVideoLikes(video.likes);
    setVideoDislikes(video.dislikes);
    setIsEditorOpen(true);
  };

  // Gallery phone image upload
  const handleGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        showToast('Image size should be under 5MB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setVideoThumbnailUrl(reader.result as string);
        showToast('Gallery image loaded successfully!');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveVideo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!videoTitle.trim()) {
      showToast('Please enter video title');
      return;
    }
    if (!videoEmbedCode.trim()) {
      showToast('Please enter iframe embed code or stream URL');
      return;
    }

    const tagList = videoTags
      .split(',')
      .map((t) => t.trim())
      .filter((t) => t.length > 0);

    if (editingVideoId) {
      updateVideo(editingVideoId, {
        title: videoTitle.trim(),
        description: videoDesc.trim(),
        category: videoCategory,
        tags: tagList,
        duration: videoDuration.trim() || '12:00',
        thumbnailUrl: videoThumbnailUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600',
        embedCode: videoEmbedCode.trim(),
        downloadUrl: videoDownloadUrl.trim(),
        isVip: videoIsVip,
        quality: videoQuality,
        views: Number(videoViews),
        likes: Number(videoLikes),
        dislikes: Number(videoDislikes),
      });
    } else {
      addVideo({
        title: videoTitle.trim(),
        description: videoDesc.trim(),
        category: videoCategory,
        tags: tagList,
        duration: videoDuration.trim() || '12:00',
        thumbnailUrl: videoThumbnailUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600',
        embedCode: videoEmbedCode.trim(),
        downloadUrl: videoDownloadUrl.trim(),
        isVip: videoIsVip,
        quality: videoQuality,
        author: 'Admin Moon',
      });
    }
    setIsEditorOpen(false);
  };

  // Sub-Admin Add
  const handleAddSubAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubUsername.trim() || !newSubPassword.trim()) {
      showToast('Username and password required');
      return;
    }
    const success = addSubAdmin({
      name: newSubName.trim() || newSubUsername.trim(),
      username: newSubUsername.trim(),
      email: newSubEmail.trim() || `${newSubUsername.trim()}@tube.xyz`,
      passwordHash: newSubPassword.trim(),
    });
    if (success) {
      setNewSubName('');
      setNewSubUsername('');
      setNewSubEmail('');
      setNewSubPassword('');
    }
  };

  // Custom Sidebar Link Add
  const handleAddCustomLink = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLinkTitle.trim() || !newLinkUrl.trim()) return;
    addCustomSidebarLink({
      title: newLinkTitle.trim(),
      url: newLinkUrl.trim(),
      badge: newLinkBadge.trim() || undefined,
      openNewTab: true,
    });
    setNewLinkTitle('');
    setNewLinkUrl('');
    setNewLinkBadge('HOT');
  };

  // Filtered Users
  const filteredUsers = users.filter((u) => {
    const q = userSearchQuery.toLowerCase();
    return (
      u.username.toLowerCase().includes(q) ||
      (u.email && u.email.toLowerCase().includes(q))
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/90 backdrop-blur-md overflow-hidden">
      <div className="relative w-full max-w-6xl h-full sm:h-[95vh] bg-[#0c0e15] sm:rounded-2xl border border-slate-800 shadow-2xl flex flex-col overflow-hidden text-slate-100">
        {/* Top Header */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3 bg-[#131622] border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-600 to-yellow-500 flex items-center justify-center text-black font-extrabold text-sm shadow">
              M
            </div>
            <div>
              <div className="text-sm sm:text-base font-extrabold text-white flex items-center gap-2">
                <span>Tube Master Admin Panel</span>
                <span className="text-[10px] font-mono bg-amber-500/20 text-amber-300 border border-amber-500/40 px-1.5 py-0.2 rounded">
                  {loggedInAdminRole === 'superadmin' ? 'SUPER-ADMIN' : loggedInAdminRole === 'subadmin' ? 'SUB-ADMIN' : 'SECURE'}
                </span>
              </div>
              <div className="text-[11px] text-slate-400">
                admin.bdtopupshop.com / Blogger Hybrid Control System (Max 3 Admins)
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {isAdminLoggedIn && (
              <button
                onClick={logoutAdmin}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 transition"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            )}
            <button
              onClick={handleCloseAdmin}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        {!isAdminLoggedIn ? (
          /* Login Screen */
          <div className="flex-1 flex items-center justify-center p-6 overflow-y-auto">
            <div className="w-full max-w-md bg-[#131622] p-6 sm:p-8 rounded-2xl border border-slate-800 shadow-2xl space-y-5">
              <div className="text-center space-y-1">
                <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-2">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <h2 className="text-xl font-extrabold text-white">Admin Authentication</h2>
                <p className="text-xs text-slate-400">
                  Password required on every session for strict security. Max 3 authorized administrators.
                </p>
              </div>

              <form onSubmit={handleAdminLogin} className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Admin / Sub-Admin Username
                  </label>
                  <input
                    type="text"
                    required
                    value={adminUser}
                    onChange={(e) => setAdminUser(e.target.value)}
                    placeholder="admin or sub-admin"
                    className="w-full bg-[#191c2b] text-slate-100 text-sm rounded-lg px-3 py-2.5 border border-slate-700 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Password</label>
                  <input
                    type="password"
                    required
                    value={adminPass}
                    onChange={(e) => setAdminPass(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-[#191c2b] text-slate-100 text-sm rounded-lg px-3 py-2.5 border border-slate-700 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-sm rounded-xl uppercase tracking-wider transition shadow-md"
                >
                  Verify & Enter Admin
                </button>
              </form>

              <div className="pt-3 border-t border-slate-800 text-center">
                <button
                  type="button"
                  onClick={() => loginAdmin('admin', 'admin123')}
                  className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold rounded-lg border border-slate-700 transition"
                >
                  ⚡ One-Click Master Login (admin / admin123)
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* Authenticated Dashboard */
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            {/* Sidebar */}
            <div className="w-full md:w-60 bg-[#10121c] border-r border-slate-800/80 p-3 flex md:flex-col justify-between shrink-0 overflow-x-auto md:overflow-y-auto">
              <div className="space-y-1 w-full flex md:flex-col gap-1 md:gap-0">
                <div className="pb-2 hidden md:block">
                  <button
                    onClick={handleOpenNewPost}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-bold text-xs shadow-lg uppercase tracking-wider transition transform hover:scale-[1.01]"
                  >
                    <PlusCircle className="w-4 h-4" />
                    <span>+ NEW POST / VIDEO</span>
                  </button>
                </div>

                <button
                  onClick={() => setCurrentTab('stats')}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                    currentTab === 'stats'
                      ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <LayoutDashboard className="w-4 h-4" />
                  <span>Stats & Dashboard</span>
                </button>

                <button
                  onClick={() => setCurrentTab('posts')}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                    currentTab === 'posts'
                      ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <FileVideo className="w-4 h-4" />
                  <span>Videos ({videos.length})</span>
                </button>

                {/* Users Management */}
                <button
                  onClick={() => setCurrentTab('users')}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                    currentTab === 'users'
                      ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <Users className="w-4 h-4" />
                  <span>Users & Logins ({users.length})</span>
                </button>

                {/* Sub-Admins */}
                <button
                  onClick={() => setCurrentTab('subadmins')}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                    currentTab === 'subadmins'
                      ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Sub-Admins ({1 + subAdmins.length}/3)</span>
                </button>

                <button
                  onClick={() => setCurrentTab('orders')}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                    currentTab === 'orders'
                      ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <DollarSign className="w-4 h-4" />
                  <span>VIP Orders ({vipOrders.filter((o) => o.status === 'pending').length})</span>
                </button>

                <button
                  onClick={() => setCurrentTab('links')}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                    currentTab === 'links'
                      ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <LinkIcon className="w-4 h-4" />
                  <span>Sidebar Links ({customSidebarLinks.length})</span>
                </button>

                <button
                  onClick={() => setCurrentTab('categories')}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                    currentTab === 'categories'
                      ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <FolderTree className="w-4 h-4" />
                  <span>Categories ({categories.length})</span>
                </button>

                <button
                  onClick={() => setCurrentTab('comments')}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                    currentTab === 'comments'
                      ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Comments ({comments.length})</span>
                </button>

                <button
                  onClick={() => setCurrentTab('ads')}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                    currentTab === 'ads'
                      ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <Megaphone className="w-4 h-4" />
                  <span>Ads & Smartlinks</span>
                </button>

                <button
                  onClick={() => setCurrentTab('settings')}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                    currentTab === 'settings'
                      ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <Settings className="w-4 h-4" />
                  <span>Site & Security</span>
                </button>
              </div>
            </div>

            {/* Viewport */}
            <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-6">
              {/* TAB 1: STATS */}
              {currentTab === 'stats' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="p-4 rounded-xl bg-[#141624] border border-slate-800">
                      <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                        Users Gained
                      </div>
                      <div className="text-2xl font-black text-white mt-1 tabular-nums">
                        {users.length}
                      </div>
                      <div className="text-[10px] text-emerald-400 mt-0.5">Active Registered</div>
                    </div>

                    <div className="p-4 rounded-xl bg-[#141624] border border-slate-800">
                      <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                        Users Today
                      </div>
                      <div className="text-2xl font-black text-white mt-1 tabular-nums">
                        {Math.floor(stats.todayViews / 3)}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">Live Visitors</div>
                    </div>

                    <div className="p-4 rounded-xl bg-[#141624] border border-slate-800">
                      <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                        Total Posts / Videos
                      </div>
                      <div className="text-2xl font-black text-white mt-1 tabular-nums">
                        {videos.length}
                      </div>
                      <div className="text-[10px] text-amber-400 mt-0.5">Published Tube Content</div>
                    </div>

                    <div className="p-4 rounded-xl bg-gradient-to-tr from-[#161a2b] to-[#1d2238] border border-amber-500/30">
                      <div className="text-[11px] font-semibold text-amber-300 uppercase tracking-wider">
                        VIP Wallet / Revenue
                      </div>
                      <div className="text-2xl font-black text-amber-400 mt-1 tabular-nums">
                        ৳{stats.totalEarningsBdt}.00
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">bKash/Nagad/Rocket Paid</div>
                    </div>
                  </div>

                  {/* Views Tracker */}
                  <div className="p-5 rounded-2xl bg-[#141624] border border-slate-800 space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                      <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-emerald-400" />
                        Blogger Views & Impression Tracker
                      </h3>
                      <span className="text-xs text-slate-400">Real-time counter</span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-center">
                      <div className="p-3 rounded-xl bg-[#181b2a] border border-slate-800">
                        <div className="text-xs text-slate-400">All Time</div>
                        <div className="text-lg font-bold text-white mt-1 tabular-nums">
                          {stats.allTimeViews.toLocaleString()} 👁️
                        </div>
                      </div>
                      <div className="p-3 rounded-xl bg-[#181b2a] border border-slate-800">
                        <div className="text-xs text-slate-400">Today</div>
                        <div className="text-lg font-bold text-emerald-400 mt-1 tabular-nums">
                          {stats.todayViews.toLocaleString()} 👁️
                        </div>
                      </div>
                      <div className="p-3 rounded-xl bg-[#181b2a] border border-slate-800">
                        <div className="text-xs text-slate-400">Yesterday</div>
                        <div className="text-lg font-bold text-slate-300 mt-1 tabular-nums">
                          {stats.yesterdayViews.toLocaleString()} 👁️
                        </div>
                      </div>
                      <div className="p-3 rounded-xl bg-[#181b2a] border border-slate-800">
                        <div className="text-xs text-slate-400">This Month</div>
                        <div className="text-lg font-bold text-sky-400 mt-1 tabular-nums">
                          {stats.thisMonthViews.toLocaleString()} 👁️
                        </div>
                      </div>
                      <div className="p-3 rounded-xl bg-[#181b2a] border border-slate-800">
                        <div className="text-xs text-slate-400">Last Month</div>
                        <div className="text-lg font-bold text-slate-300 mt-1 tabular-nums">
                          {stats.lastMonthViews.toLocaleString()} 👁️
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: POSTS & VIDEOS */}
              {currentTab === 'posts' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <FileVideo className="w-5 h-5 text-amber-400" />
                      Manage Videos & Embed Codes ({videos.length})
                    </h3>
                    <button
                      onClick={handleOpenNewPost}
                      className="px-3 py-2 bg-gradient-to-r from-orange-500 to-amber-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow"
                    >
                      <PlusCircle className="w-4 h-4" />
                      <span>Upload Video</span>
                    </button>
                  </div>

                  <div className="divide-y divide-slate-800 bg-[#131522] rounded-xl border border-slate-800 overflow-hidden">
                    {videos.map((vid) => (
                      <div
                        key={vid.id}
                        className="p-3 sm:p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 hover:bg-[#181b2a] transition"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <img
                            src={vid.thumbnailUrl}
                            alt={vid.title}
                            className="w-20 h-14 object-cover rounded-lg shrink-0 border border-slate-800"
                            referrerPolicy="no-referrer"
                          />
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="text-xs sm:text-sm font-bold text-slate-100 truncate">
                                {vid.title}
                              </span>
                              {vid.isVip && (
                                <span className="text-[10px] font-black text-amber-300 bg-amber-950 px-1.5 py-0.2 rounded border border-amber-600/40">
                                  VIP
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                              <span className="capitalize">{vid.category}</span>
                              <span>·</span>
                              <span>{vid.duration}</span>
                              <span>·</span>
                              <span>{vid.views} views</span>
                              <span>·</span>
                              <span>{vid.likes} likes</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                          <button
                            onClick={() => handleOpenEditPost(vid)}
                            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                            title="Edit Video, Views & Likes"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => deleteVideo(vid.id)}
                            className="p-2 rounded-lg bg-red-950/40 hover:bg-red-900/60 text-red-400 hover:text-red-200 border border-red-900/40 transition"
                            title="Delete Video"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: USERS & LOGINS MANAGEMENT */}
              {currentTab === 'users' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h3 className="text-base font-bold text-white flex items-center gap-2">
                        <Users className="w-5 h-5 text-amber-400" />
                        Registered Users & Login Logs ({users.length})
                      </h3>
                      <p className="text-xs text-slate-400">
                        View user credentials, passwords, login timestamps, and edit or grant VIP status.
                      </p>
                    </div>

                    <div className="relative w-full sm:w-64">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        value={userSearchQuery}
                        onChange={(e) => setUserSearchQuery(e.target.value)}
                        placeholder="Search by username or email..."
                        className="w-full bg-[#181a28] text-xs rounded-lg pl-9 pr-3 py-2 border border-slate-700"
                      />
                    </div>
                  </div>

                  <div className="divide-y divide-slate-800 bg-[#131522] rounded-xl border border-slate-800 overflow-hidden">
                    {filteredUsers.map((u) => (
                      <div
                        key={u.id}
                        className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 hover:bg-[#181b2a] transition"
                      >
                        <div className="flex items-center gap-3">
                          <img
                            src={u.avatar}
                            alt={u.username}
                            className="w-12 h-12 rounded-full border border-amber-400 object-cover shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-sm text-white">{u.username}</span>
                              {u.isVip ? (
                                <span className="text-[10px] font-black bg-amber-950 text-amber-300 border border-amber-500/50 px-2 py-0.5 rounded-full flex items-center gap-1">
                                  <Crown className="w-3 h-3 fill-amber-300" /> VIP MEMBER
                                </span>
                              ) : (
                                <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded">
                                  Free User
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-slate-400 mt-0.5 flex flex-wrap gap-2">
                              <span>Password: <strong className="font-mono text-amber-300">{u.password || 'N/A'}</strong></span>
                              <span>·</span>
                              <span>Email: {u.email}</span>
                            </div>
                            <div className="text-[11px] text-slate-500 mt-0.5">
                              Registered: {u.createdAt} · Last Login: <strong className="text-emerald-400">{u.lastLoginAt}</strong>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-center">
                          <button
                            onClick={() => {
                              updateUserByAdmin(u.id, { isVip: !u.isVip });
                            }}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                              u.isVip
                                ? 'bg-amber-950 text-amber-300 border border-amber-500/40 hover:bg-amber-900'
                                : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                            }`}
                          >
                            {u.isVip ? 'Revoke VIP' : 'Grant VIP'}
                          </button>
                          <button
                            onClick={() => deleteUserByAdmin(u.id)}
                            className="p-1.5 rounded-lg bg-red-950/40 hover:bg-red-900/60 text-red-400 border border-red-800"
                            title="Delete User"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 4: SUB-ADMINS (Max 3 admins total) */}
              {currentTab === 'subadmins' && (
                <div className="space-y-5">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-amber-400" />
                      Administrators & Sub-Admins Management
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Security policy: Maximum 3 total admins allowed (1 Super-Admin + up to 2 Sub-Admins).
                    </p>
                  </div>

                  {/* Super-Admin Card */}
                  <div className="p-4 rounded-xl bg-[#161a29] border border-amber-500/40 flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-amber-300">
                          Master Super-Admin (You)
                        </span>
                        <span className="text-[10px] font-black bg-amber-500 text-black px-1.5 py-0.2 rounded">
                          OWNER
                        </span>
                      </div>
                      <div className="text-xs text-slate-400 mt-1 font-mono">
                        Username: <strong className="text-white">{siteSettings.adminUsername}</strong> · Password Hash: ••••••••
                      </div>
                    </div>
                    <span className="text-xs text-emerald-400 font-bold">Primary Root</span>
                  </div>

                  {/* Sub-Admins List */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                      Sub-Admins ({subAdmins.length}/2 Active)
                    </h4>
                    {subAdmins.map((sub) => (
                      <div
                        key={sub.id}
                        className="p-4 rounded-xl bg-[#141624] border border-slate-800 flex items-center justify-between"
                      >
                        <div>
                          <div className="text-sm font-bold text-white">{sub.name}</div>
                          <div className="text-xs text-slate-400 font-mono mt-0.5">
                            Username: <strong className="text-amber-300">{sub.username}</strong> · Password: <strong className="text-amber-300">{sub.passwordHash}</strong>
                          </div>
                          <div className="text-[10px] text-slate-500">Created: {sub.createdAt}</div>
                        </div>
                        <button
                          onClick={() => removeSubAdmin(sub.id)}
                          className="px-3 py-1.5 rounded-lg bg-red-950/60 hover:bg-red-900 text-red-300 text-xs font-semibold border border-red-800 transition"
                        >
                          Remove Sub-Admin
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* Add Sub-Admin Form if under limit */}
                  {subAdmins.length < 2 && (
                    <form
                      onSubmit={handleAddSubAdmin}
                      className="p-4 rounded-xl bg-[#141624] border border-slate-800 space-y-3 max-w-xl"
                    >
                      <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                        <UserPlus className="w-4 h-4" /> Add New Sub-Admin
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <input
                          type="text"
                          required
                          value={newSubName}
                          onChange={(e) => setNewSubName(e.target.value)}
                          placeholder="Full Name (e.g. Shakil Moderator)"
                          className="bg-[#1a1d2e] text-xs rounded-lg p-2 border border-slate-700"
                        />
                        <input
                          type="text"
                          required
                          value={newSubUsername}
                          onChange={(e) => setNewSubUsername(e.target.value)}
                          placeholder="Username"
                          className="bg-[#1a1d2e] text-xs rounded-lg p-2 border border-slate-700"
                        />
                        <input
                          type="email"
                          value={newSubEmail}
                          onChange={(e) => setNewSubEmail(e.target.value)}
                          placeholder="Email Address"
                          className="bg-[#1a1d2e] text-xs rounded-lg p-2 border border-slate-700"
                        />
                        <input
                          type="password"
                          required
                          value={newSubPassword}
                          onChange={(e) => setNewSubPassword(e.target.value)}
                          placeholder="Login Password"
                          className="bg-[#1a1d2e] text-xs rounded-lg p-2 border border-slate-700"
                        />
                      </div>
                      <button
                        type="submit"
                        className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg uppercase tracking-wider transition"
                      >
                        Create Sub-Admin Account
                      </button>
                    </form>
                  )}
                </div>
              )}

              {/* TAB 5: VIP ORDERS & PRICING ADJUSTMENT */}
              {currentTab === 'orders' && (
                <div className="space-y-6">
                  {/* Pricing adjustment controls */}
                  <div className="p-4 rounded-xl bg-[#141624] border border-amber-500/30 space-y-3">
                    <h3 className="text-sm font-bold text-amber-400 flex items-center gap-2">
                      <DollarSign className="w-4 h-4" />
                      Adjust VIP Subscription Prices (BDT)
                    </h3>
                    <p className="text-xs text-slate-400">
                      Change the price of VIP packages anytime. Updates immediately on the user payment screen.
                    </p>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {vipPackages.map((pkg) => (
                        <div key={pkg.id} className="p-3 rounded-lg bg-[#191c2b] border border-slate-800 space-y-1">
                          <span className="text-xs font-bold text-slate-200">{pkg.title}</span>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs text-slate-400">৳</span>
                            <input
                              type="number"
                              defaultValue={pkg.priceBdt}
                              onBlur={(e) => {
                                const val = Number(e.target.value);
                                if (val > 0) updateVipPackagePrice(pkg.id, val);
                              }}
                              className="w-full bg-[#121420] text-xs font-bold text-amber-400 p-1.5 rounded border border-slate-700 tabular-nums"
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Transactions table */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                      Pending & Past Transactions ({vipOrders.length})
                    </h4>
                    {vipOrders.map((ord) => (
                      <div
                        key={ord.id}
                        className="p-4 rounded-xl bg-[#141624] border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-white">{ord.userName}</span>
                            <span
                              className={`text-[10px] font-black px-2 py-0.5 rounded uppercase ${
                                ord.gateway === 'bkash'
                                  ? 'bg-[#e2136e] text-white'
                                  : ord.gateway === 'nagad'
                                  ? 'bg-[#f7941d] text-white'
                                  : 'bg-[#8c3494] text-white'
                              }`}
                            >
                              {ord.gateway}
                            </span>
                            <span className="text-xs font-black text-amber-400">
                              ৳{ord.priceBdt} BDT ({ord.packageType})
                            </span>
                          </div>
                          <div className="text-xs text-slate-300">
                            Sender Phone: <span className="font-mono font-bold text-white">{ord.userPhone}</span> · TrxID:{' '}
                            <span className="font-mono font-extrabold text-amber-300 bg-black/40 px-1.5 py-0.5 rounded">
                              {ord.trxId}
                            </span>
                          </div>
                          <div className="text-[10px] text-slate-500">Submitted: {ord.createdAt}</div>
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-center">
                          {ord.status === 'pending' ? (
                            <>
                              <button
                                onClick={() => approveVipOrder(ord.id)}
                                className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow transition"
                              >
                                <CheckCircle className="w-3.5 h-3.5" />
                                <span>Accept & Grant VIP</span>
                              </button>
                              <button
                                onClick={() => rejectVipOrder(ord.id)}
                                className="flex items-center gap-1 px-3 py-1.5 bg-red-950 text-red-300 hover:bg-red-900 rounded-lg text-xs font-semibold border border-red-800 transition"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                <span>Reject</span>
                              </button>
                            </>
                          ) : (
                            <span
                              className={`text-xs font-bold px-2.5 py-1 rounded-full uppercase ${
                                ord.status === 'approved'
                                  ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-600/50'
                                  : 'bg-red-950/80 text-red-400 border border-red-600/50'
                              }`}
                            >
                              {ord.status}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 6: CUSTOM SIDEBAR LINKS */}
              {currentTab === 'links' && (
                <div className="space-y-4">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <LinkIcon className="w-5 h-5 text-amber-400" />
                      Manage Sidebar Links & Telegram Channels
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Add custom promotional links, Telegram channels, or backup links to the left side menu.
                    </p>
                  </div>

                  <form
                    onSubmit={handleAddCustomLink}
                    className="p-4 rounded-xl bg-[#141624] border border-slate-800 space-y-3 max-w-xl"
                  >
                    <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                      + Add New Menu Link
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <input
                        type="text"
                        required
                        value={newLinkTitle}
                        onChange={(e) => setNewLinkTitle(e.target.value)}
                        placeholder="Link Title (e.g. VIP Telegram)"
                        className="bg-[#1a1d2e] text-xs rounded-lg p-2 border border-slate-700"
                      />
                      <input
                        type="url"
                        required
                        value={newLinkUrl}
                        onChange={(e) => setNewLinkUrl(e.target.value)}
                        placeholder="Target URL (https://...)"
                        className="bg-[#1a1d2e] text-xs rounded-lg p-2 border border-slate-700"
                      />
                      <input
                        type="text"
                        value={newLinkBadge}
                        onChange={(e) => setNewLinkBadge(e.target.value)}
                        placeholder="Badge (e.g. HOT)"
                        className="bg-[#1a1d2e] text-xs rounded-lg p-2 border border-slate-700"
                      />
                    </div>
                    <button
                      type="submit"
                      className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg uppercase tracking-wider transition"
                    >
                      Save Link to Sidebar
                    </button>
                  </form>

                  <div className="divide-y divide-slate-800 bg-[#131522] rounded-xl border border-slate-800">
                    {customSidebarLinks.map((l) => (
                      <div key={l.id} className="p-3.5 flex items-center justify-between">
                        <div>
                          <div className="text-xs font-bold text-white flex items-center gap-2">
                            <span>{l.title}</span>
                            {l.badge && (
                              <span className="text-[9px] bg-amber-500/20 text-amber-400 px-1 rounded">
                                {l.badge}
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono mt-0.5">{l.url}</div>
                        </div>
                        <button
                          onClick={() => deleteCustomSidebarLink(l.id)}
                          className="p-1.5 rounded-lg text-red-400 hover:bg-red-900/40"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 7: CATEGORIES */}
              {currentTab === 'categories' && (
                <div className="space-y-5">
                  <div className="p-4 rounded-xl bg-[#141624] border border-slate-800">
                    <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                      Add New Category
                    </h4>
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (!newCatName.trim()) return;
                        addCategory(newCatName.trim(), newCatSlug.trim() || newCatName.trim());
                        setNewCatName('');
                        setNewCatSlug('');
                      }}
                      className="flex flex-col sm:flex-row gap-2"
                    >
                      <input
                        type="text"
                        required
                        value={newCatName}
                        onChange={(e) => setNewCatName(e.target.value)}
                        placeholder="Category Name"
                        className="flex-1 bg-[#1a1d2d] text-slate-100 text-xs sm:text-sm rounded-lg px-3 py-2 border border-slate-700"
                      />
                      <input
                        type="text"
                        value={newCatSlug}
                        onChange={(e) => setNewCatSlug(e.target.value)}
                        placeholder="Slug (optional)"
                        className="bg-[#1a1d2d] text-slate-100 text-xs sm:text-sm rounded-lg px-3 py-2 border border-slate-700"
                      />
                      <button
                        type="submit"
                        className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm rounded-lg transition"
                      >
                        Add Category
                      </button>
                    </form>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {categories.map((cat) => (
                      <div
                        key={cat.id}
                        className="p-3 rounded-xl bg-[#131522] border border-slate-800 flex items-center justify-between"
                      >
                        <div>
                          <div className="text-sm font-bold text-slate-200">{cat.name}</div>
                          <div className="text-[11px] text-slate-400 font-mono">
                            slug: {cat.slug} · Count: <strong className="text-emerald-400">{cat.count}</strong>
                          </div>
                        </div>
                        {cat.id !== 'all' && (
                          <button
                            onClick={() => deleteCategory(cat.id)}
                            className="p-1.5 rounded-lg text-red-400 hover:text-white hover:bg-red-900/50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 8: COMMENTS */}
              {currentTab === 'comments' && (
                <div className="space-y-4">
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-red-500" />
                    Moderate Video Comments ({comments.length})
                  </h3>

                  <div className="space-y-2">
                    {comments.map((cm) => (
                      <div
                        key={cm.id}
                        className="p-3 rounded-xl bg-[#131522] border border-slate-800 flex items-center justify-between gap-3"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 text-xs">
                            <span className="font-bold text-red-400">{cm.userName}</span>
                            <span className="text-slate-500">{cm.createdAt}</span>
                          </div>
                          <p className="text-xs text-slate-200">{cm.text}</p>
                        </div>
                        <button
                          onClick={() => deleteComment(cm.id)}
                          className="p-2 rounded-lg text-red-400 hover:bg-red-900/40"
                          title="Delete Comment"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 9: ADS */}
              {currentTab === 'ads' && (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    updateAdSettings({
                      topBannerHtml,
                      topBannerImage: topBannerImg,
                      topBannerLink,
                      smartLink1,
                      smartLink2,
                      smartLink3,
                      directDownloadLink: directDownload,
                    });
                  }}
                  className="p-4 rounded-xl bg-[#131522] border border-slate-800 space-y-4 max-w-2xl"
                >
                  <h3 className="text-sm font-bold text-slate-200">
                    Adsterra & Smartlink Monetization Controls
                  </h3>

                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">
                      728x90 Header Ad Code (HTML/Script)
                    </label>
                    <textarea
                      rows={2}
                      value={topBannerHtml}
                      onChange={(e) => setTopBannerHtml(e.target.value)}
                      placeholder="Paste Adsterra banner script..."
                      className="w-full bg-[#181b2a] text-slate-100 font-mono text-xs rounded-lg p-2.5 border border-slate-700"
                    />
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <label className="text-xs font-bold text-amber-300 block">
                      Download 3-Step Smart Links
                    </label>
                    <input
                      type="text"
                      value={smartLink1}
                      onChange={(e) => setSmartLink1(e.target.value)}
                      placeholder="Smartlink 1"
                      className="w-full bg-[#181b2a] text-slate-100 font-mono text-xs rounded-lg p-2 border border-slate-700"
                    />
                    <input
                      type="text"
                      value={smartLink2}
                      onChange={(e) => setSmartLink2(e.target.value)}
                      placeholder="Smartlink 2"
                      className="w-full bg-[#181b2a] text-slate-100 font-mono text-xs rounded-lg p-2 border border-slate-700"
                    />
                    <input
                      type="text"
                      value={smartLink3}
                      onChange={(e) => setSmartLink3(e.target.value)}
                      placeholder="Smartlink 3"
                      className="w-full bg-[#181b2a] text-slate-100 font-mono text-xs rounded-lg p-2 border border-slate-700"
                    />
                  </div>

                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg uppercase tracking-wider transition"
                  >
                    Save Ad Settings
                  </button>
                </form>
              )}

              {/* TAB 10: SETTINGS */}
              {currentTab === 'settings' && (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    updateSiteSettings({
                      siteTitle,
                      siteLogoText: siteLogo,
                      adminUsername: adminUsernameInput,
                      adminPasswordHash: adminPasswordInput,
                      bkashNumber: bkashNum,
                      nagadNumber: nagadNum,
                      rocketNumber: rocketNum,
                      antiCopyEnabled: antiCopyToggle,
                      ageGateEnabled: ageGateToggle,
                    });
                  }}
                  className="p-4 sm:p-5 rounded-xl bg-[#131522] border border-slate-800 space-y-4 max-w-2xl"
                >
                  <h3 className="text-sm font-bold text-slate-200">
                    Site Branding, Mobile Banking Numbers & Security
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Site Name</label>
                      <input
                        type="text"
                        value={siteTitle}
                        onChange={(e) => setSiteTitle(e.target.value)}
                        className="w-full bg-[#181b2a] text-slate-100 text-xs rounded-lg p-2.5 border border-slate-700"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Logo Text Badge</label>
                      <input
                        type="text"
                        value={siteLogo}
                        onChange={(e) => setSiteLogo(e.target.value)}
                        className="w-full bg-[#181b2a] text-slate-100 text-xs rounded-lg p-2.5 border border-slate-700"
                      />
                    </div>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <label className="text-xs font-bold text-amber-300 block">
                      Payment Phone Numbers (Personal Send Money)
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <input
                        type="text"
                        value={bkashNum}
                        onChange={(e) => setBkashNum(e.target.value)}
                        placeholder="bKash"
                        className="w-full bg-[#181b2a] text-slate-100 font-mono text-xs rounded-lg p-2 border border-slate-700"
                      />
                      <input
                        type="text"
                        value={nagadNum}
                        onChange={(e) => setNagadNum(e.target.value)}
                        placeholder="Nagad"
                        className="w-full bg-[#181b2a] text-slate-100 font-mono text-xs rounded-lg p-2 border border-slate-700"
                      />
                      <input
                        type="text"
                        value={rocketNum}
                        onChange={(e) => setRocketNum(e.target.value)}
                        placeholder="Rocket"
                        className="w-full bg-[#181b2a] text-slate-100 font-mono text-xs rounded-lg p-2 border border-slate-700"
                      />
                    </div>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <label className="text-xs font-bold text-amber-300 block">
                      Super-Admin Master Credentials
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <input
                        type="text"
                        value={adminUsernameInput}
                        onChange={(e) => setAdminUsernameInput(e.target.value)}
                        className="w-full bg-[#181b2a] text-slate-100 text-xs rounded-lg p-2 border border-slate-700"
                      />
                      <input
                        type="text"
                        value={adminPasswordInput}
                        onChange={(e) => setAdminPasswordInput(e.target.value)}
                        className="w-full bg-[#181b2a] text-slate-100 font-mono text-xs rounded-lg p-2 border border-slate-700"
                      />
                    </div>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-200">Anti-Copy & Right Click Off</span>
                      <input
                        type="checkbox"
                        checked={antiCopyToggle}
                        onChange={(e) => setAntiCopyToggle(e.target.checked)}
                        className="w-4 h-4 accent-amber-500"
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-200">18+ Age Verification Gate</span>
                      <input
                        type="checkbox"
                        checked={ageGateToggle}
                        onChange={(e) => setAgeGateToggle(e.target.checked)}
                        className="w-4 h-4 accent-amber-500"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg uppercase tracking-wider transition"
                  >
                    Save All Site Settings
                  </button>
                </form>
              )}
            </div>
          </div>
        )}

        {/* Video Editor Modal (With Views & Likes & Embed controls) */}
        {isEditorOpen && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md overflow-y-auto">
            <div className="relative w-full max-w-2xl bg-[#11131e] rounded-2xl border border-slate-800 shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
              <div className="flex items-center justify-between px-5 py-3.5 bg-[#161928] border-b border-slate-800 shrink-0">
                <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                  <FileVideo className="w-4 h-4 text-amber-400" />
                  {editingVideoId ? 'Edit Video & Metrics' : 'Publish New Video (Embed Iframe)'}
                </h3>
                <button
                  onClick={() => setIsEditorOpen(false)}
                  className="p-1 text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveVideo} className="p-4 sm:p-6 overflow-y-auto space-y-4 flex-1">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Video Title</label>
                  <input
                    type="text"
                    required
                    value={videoTitle}
                    onChange={(e) => setVideoTitle(e.target.value)}
                    placeholder="e.g. প্রাইভেট স্যার আর ছাত্রীর ভাইরাল ভিডিও VXL-038"
                    className="w-full bg-[#181a28] text-slate-100 text-xs sm:text-sm rounded-lg px-3 py-2 border border-slate-700 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">Category</label>
                    <select
                      value={videoCategory}
                      onChange={(e) => setVideoCategory(e.target.value)}
                      className="w-full bg-[#181a28] text-slate-100 text-xs rounded-lg px-3 py-2 border border-slate-700"
                    >
                      {categories.map((c) => (
                        <option key={c.id} value={c.slug}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">Duration</label>
                    <input
                      type="text"
                      value={videoDuration}
                      onChange={(e) => setVideoDuration(e.target.value)}
                      placeholder="18:42"
                      className="w-full bg-[#181a28] text-slate-100 text-xs rounded-lg px-3 py-2 border border-slate-700"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">Quality</label>
                    <select
                      value={videoQuality}
                      onChange={(e) => setVideoQuality(e.target.value as any)}
                      className="w-full bg-[#181a28] text-slate-100 text-xs rounded-lg px-3 py-2 border border-slate-700"
                    >
                      <option value="HD">HD 1080p</option>
                      <option value="4K">4K Ultra HD</option>
                      <option value="SD">SD 720p</option>
                    </select>
                  </div>
                </div>

                {/* Direct Views, Likes & Dislikes Adjustment (As requested by user!) */}
                <div className="p-3 rounded-xl bg-[#171926] border border-amber-500/30 space-y-2">
                  <label className="text-xs font-bold text-amber-300 block">
                    Modify Video Live Metrics (Views & Likes)
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <span className="text-[11px] text-slate-400 block mb-0.5">Total Views:</span>
                      <input
                        type="number"
                        value={videoViews}
                        onChange={(e) => setVideoViews(Number(e.target.value))}
                        className="w-full bg-[#121420] text-xs text-amber-400 font-bold p-2 rounded border border-slate-700"
                      />
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block mb-0.5">Total Likes:</span>
                      <input
                        type="number"
                        value={videoLikes}
                        onChange={(e) => setVideoLikes(Number(e.target.value))}
                        className="w-full bg-[#121420] text-xs text-rose-400 font-bold p-2 rounded border border-slate-700"
                      />
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block mb-0.5">Dislikes:</span>
                      <input
                        type="number"
                        value={videoDislikes}
                        onChange={(e) => setVideoDislikes(Number(e.target.value))}
                        className="w-full bg-[#121420] text-xs text-slate-300 font-bold p-2 rounded border border-slate-700"
                      />
                    </div>
                  </div>
                </div>

                {/* Thumbnail from Phone Gallery */}
                <div className="p-3 rounded-xl bg-[#171926] border border-slate-800 space-y-2">
                  <label className="text-xs font-bold text-amber-300 block">
                    Thumbnail Cover (Gallery Upload or Image Link)
                  </label>
                  <div className="flex flex-col sm:flex-row gap-2 items-center">
                    <label className="flex-1 w-full cursor-pointer flex items-center justify-center gap-2 px-3 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-xs font-semibold text-slate-200 border border-slate-700 transition">
                      <Upload className="w-4 h-4 text-amber-400" />
                      <span>Upload from Phone Gallery</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleGalleryUpload}
                        className="hidden"
                      />
                    </label>
                    <span className="text-xs text-slate-500">OR</span>
                    <input
                      type="text"
                      value={videoThumbnailUrl}
                      onChange={(e) => setVideoThumbnailUrl(e.target.value)}
                      placeholder="Paste Image URL"
                      className="flex-1 w-full bg-[#12141f] text-slate-100 text-xs rounded-lg px-3 py-2 border border-slate-700"
                    />
                  </div>
                  {videoThumbnailUrl && (
                    <img
                      src={videoThumbnailUrl}
                      alt="Preview"
                      className="w-20 h-12 object-cover rounded border border-slate-700 mt-2"
                      referrerPolicy="no-referrer"
                    />
                  )}
                </div>

                {/* Embed Iframe Code */}
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    Embed Iframe Code or Video URL
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={videoEmbedCode}
                    onChange={(e) => setVideoEmbedCode(e.target.value)}
                    placeholder='<iframe src="https://streamtape.com/e/..." allowfullscreen></iframe> or https://...'
                    className="w-full bg-[#181a28] text-slate-100 font-mono text-xs rounded-lg p-2.5 border border-slate-700 focus:outline-none focus:border-amber-400"
                  />
                </div>

                {/* Mega Download Link */}
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    Direct Mega.nz / Storage Download URL
                  </label>
                  <input
                    type="text"
                    value={videoDownloadUrl}
                    onChange={(e) => setVideoDownloadUrl(e.target.value)}
                    placeholder="https://mega.nz/file/..."
                    className="w-full bg-[#181a28] text-slate-100 font-mono text-xs rounded-lg px-3 py-2 border border-slate-700"
                  />
                </div>

                {/* Tags & VIP Toggle */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">
                      Tags (comma separated)
                    </label>
                    <input
                      type="text"
                      value={videoTags}
                      onChange={(e) => setVideoTags(e.target.value)}
                      placeholder="Public Bang, Desi, Leaks"
                      className="w-full bg-[#181a28] text-slate-100 text-xs rounded-lg px-3 py-2 border border-slate-700"
                    />
                  </div>

                  <div className="flex items-center gap-2 pt-4">
                    <input
                      type="checkbox"
                      id="isVipCheck"
                      checked={videoIsVip}
                      onChange={(e) => setVideoIsVip(e.target.checked)}
                      className="w-4 h-4 accent-amber-500 rounded"
                    />
                    <label htmlFor="isVipCheck" className="text-xs font-bold text-amber-300 cursor-pointer">
                      VIP Exclusive Video (Requires VIP Pass)
                    </label>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsEditorOpen(false)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-gradient-to-r from-orange-500 to-amber-500 text-white text-xs font-bold rounded-lg shadow uppercase tracking-wider"
                  >
                    {editingVideoId ? 'Save Changes' : 'Publish Post'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
