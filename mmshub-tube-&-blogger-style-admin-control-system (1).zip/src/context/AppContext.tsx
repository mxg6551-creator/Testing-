import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Video,
  Category,
  Comment,
  VipOrder,
  AdSettings,
  SiteSettings,
  SiteStats,
  User,
  SubAdmin,
  CustomSidebarLink,
  VipPackage,
} from '../types';
import {
  INITIAL_VIDEOS,
  INITIAL_CATEGORIES,
  INITIAL_COMMENTS,
  INITIAL_STATS,
  INITIAL_AD_SETTINGS,
  INITIAL_SITE_SETTINGS,
  INITIAL_VIP_ORDERS,
  INITIAL_SUB_ADMINS,
  INITIAL_CUSTOM_SIDEBAR_LINKS,
  INITIAL_VIP_PACKAGES,
  INITIAL_USERS,
  ADULT_STAR_AVATARS,
} from '../services/initialData';
import { TRANSLATIONS, Language } from '../services/translations';

interface AppContextType {
  // Localization & Theme
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: keyof typeof TRANSLATIONS.en) => string;
  isNightMode: boolean;
  setIsNightMode: (val: boolean) => void;

  // Data
  videos: Video[];
  categories: Category[];
  comments: Comment[];
  vipOrders: VipOrder[];
  adSettings: AdSettings;
  siteSettings: SiteSettings;
  stats: SiteStats;
  currentUser: User | null;
  activeVideo: Video | null;
  searchQuery: string;
  selectedCategory: string;
  pricingFilter: 'all' | 'free' | 'vip';
  isAgeGatePassed: boolean;

  // Sub-Admins & Custom Links & VIP Packages & Users
  subAdmins: SubAdmin[];
  customSidebarLinks: CustomSidebarLink[];
  vipPackages: VipPackage[];
  users: User[];

  // Modals & Navigation
  isSidebarOpen: boolean;
  isAdminOpen: boolean;
  isAdminLoggedIn: boolean;
  loggedInAdminRole: 'superadmin' | 'subadmin' | null;
  isAuthModalOpen: boolean;
  isVipModalOpen: boolean;
  isSettingsModalOpen: boolean;
  isGuideModalOpen: boolean;
  toastMessage: string | null;

  // Setters
  setActiveVideo: (video: Video | null) => void;
  setSearchQuery: (query: string) => void;
  setSelectedCategory: (cat: string) => void;
  setPricingFilter: (filter: 'all' | 'free' | 'vip') => void;
  setIsAgeGatePassed: (val: boolean) => void;
  setIsSidebarOpen: (val: boolean) => void;
  setIsAdminOpen: (val: boolean) => void;
  setIsAuthModalOpen: (val: boolean) => void;
  setIsVipModalOpen: (val: boolean) => void;
  setIsSettingsModalOpen: (val: boolean) => void;
  setIsGuideModalOpen: (val: boolean) => void;
  showToast: (msg: string) => void;

  // Video Actions
  addVideo: (video: Omit<Video, 'id' | 'createdAt' | 'views' | 'likes' | 'dislikes'>) => void;
  updateVideo: (id: string, updated: Partial<Video>) => void;
  deleteVideo: (id: string) => void;
  incrementVideoView: (id: string) => void;
  likeVideo: (id: string) => void;
  dislikeVideo: (id: string) => void;
  toggleSaveVideo: (id: string) => void;

  // Comments
  addComment: (videoId: string, text: string) => boolean;
  deleteComment: (commentId: string) => void;

  // VIP & Payments
  submitVipOrder: (order: {
    userPhone: string;
    packageType: '1 Month' | '3 Months' | '6 Months' | '1 Year';
    priceBdt: number;
    gateway: 'bkash' | 'nagad' | 'rocket';
    trxId: string;
  }) => void;
  approveVipOrder: (orderId: string) => void;
  rejectVipOrder: (orderId: string) => void;
  updateVipPackagePrice: (id: '1 Month' | '3 Months' | '6 Months' | '1 Year', newPrice: number) => void;

  // Settings & Monetization
  updateAdSettings: (newAds: Partial<AdSettings>) => void;
  updateSiteSettings: (newSettings: Partial<SiteSettings>) => void;

  // Categories
  addCategory: (name: string, slug: string) => void;
  deleteCategory: (id: string) => void;

  // Sub-Admin Management (Max 3 admins total)
  addSubAdmin: (admin: Omit<SubAdmin, 'id' | 'createdAt'>) => boolean;
  removeSubAdmin: (id: string) => void;

  // Custom Sidebar Links
  addCustomSidebarLink: (link: Omit<CustomSidebarLink, 'id'>) => void;
  deleteCustomSidebarLink: (id: string) => void;

  // User Management
  registerOrLoginUser: (username: string, password?: string) => void;
  logoutUser: () => void;
  changeUsername: (newUsername: string) => { success: boolean; message: string };
  changePassword: (oldPass: string, newPass: string) => { success: boolean; message: string };
  changeAvatar: (newAvatarUrl: string) => { success: boolean; message: string };
  updateUserByAdmin: (userId: string, updated: Partial<User>) => void;
  deleteUserByAdmin: (userId: string) => void;

  // Admin Auth
  loginAdmin: (user: string, pass: string) => boolean;
  logoutAdmin: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Language & Theme state
  const [language, setLanguage] = useState<Language>(() => {
    return (localStorage.getItem('mmshub_language') as Language) || 'en';
  });

  const [isNightMode, setIsNightMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('mmshub_night_mode');
    return saved !== null ? saved === 'true' : true;
  });

  // Videos
  const [videos, setVideos] = useState<Video[]>(() => {
    const saved = localStorage.getItem('mmshub_videos');
    return saved ? JSON.parse(saved) : INITIAL_VIDEOS;
  });

  // Categories
  const [baseCategories, setBaseCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem('mmshub_categories');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });

  // Dynamic real count for categories
  const categories = React.useMemo(() => {
    return baseCategories.map((cat) => {
      if (cat.slug === 'all') {
        return { ...cat, count: videos.length };
      }
      const realCount = videos.filter((v) => v.category === cat.slug).length;
      return { ...cat, count: realCount };
    });
  }, [baseCategories, videos]);

  // Comments
  const [comments, setComments] = useState<Comment[]>(() => {
    const saved = localStorage.getItem('mmshub_comments');
    return saved ? JSON.parse(saved) : INITIAL_COMMENTS;
  });

  // VIP Orders
  const [vipOrders, setVipOrders] = useState<VipOrder[]>(() => {
    const saved = localStorage.getItem('mmshub_vip_orders');
    return saved ? JSON.parse(saved) : INITIAL_VIP_ORDERS;
  });

  // VIP Packages with dynamic pricing
  const [vipPackages, setVipPackages] = useState<VipPackage[]>(() => {
    const saved = localStorage.getItem('mmshub_vip_packages');
    return saved ? JSON.parse(saved) : INITIAL_VIP_PACKAGES;
  });

  // Sub-Admins list (Max 2 sub-admins + 1 main admin = 3 max)
  const [subAdmins, setSubAdmins] = useState<SubAdmin[]>(() => {
    const saved = localStorage.getItem('mmshub_sub_admins');
    return saved ? JSON.parse(saved) : INITIAL_SUB_ADMINS;
  });

  // Custom Sidebar Links
  const [customSidebarLinks, setCustomSidebarLinks] = useState<CustomSidebarLink[]>(() => {
    const saved = localStorage.getItem('mmshub_custom_links');
    return saved ? JSON.parse(saved) : INITIAL_CUSTOM_SIDEBAR_LINKS;
  });

  // Registered Users list
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('mmshub_users');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  // Ads & Settings
  const [adSettings, setAdSettings] = useState<AdSettings>(() => {
    const saved = localStorage.getItem('mmshub_ads');
    return saved ? JSON.parse(saved) : INITIAL_AD_SETTINGS;
  });

  const [siteSettings, setSiteSettings] = useState<SiteSettings>(() => {
    const saved = localStorage.getItem('mmshub_site_settings');
    return saved ? JSON.parse(saved) : INITIAL_SITE_SETTINGS;
  });

  const [stats, setStats] = useState<SiteStats>(() => {
    const saved = localStorage.getItem('mmshub_stats');
    return saved ? JSON.parse(saved) : INITIAL_STATS;
  });

  // Current logged in tube user
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('mmshub_current_user');
    return saved ? JSON.parse(saved) : INITIAL_USERS[0];
  });

  // Admin Session Security (requires password on each session)
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(false);
  const [loggedInAdminRole, setLoggedInAdminRole] = useState<'superadmin' | 'subadmin' | null>(null);

  // Active playing video & filters
  const [activeVideo, setActiveVideo] = useState<Video | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [pricingFilter, setPricingFilter] = useState<'all' | 'free' | 'vip'>('all');
  const [isAgeGatePassed, setIsAgeGatePassed] = useState<boolean>(() => {
    return localStorage.getItem('mmshub_age_gate') === 'passed';
  });

  // Modals state
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isVipModalOpen, setIsVipModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isGuideModalOpen, setIsGuideModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('mmshub_language', language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem('mmshub_night_mode', isNightMode ? 'true' : 'false');
    if (isNightMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isNightMode]);

  useEffect(() => {
    localStorage.setItem('mmshub_videos', JSON.stringify(videos));
  }, [videos]);

  useEffect(() => {
    localStorage.setItem('mmshub_categories', JSON.stringify(baseCategories));
  }, [baseCategories]);

  useEffect(() => {
    localStorage.setItem('mmshub_comments', JSON.stringify(comments));
  }, [comments]);

  useEffect(() => {
    localStorage.setItem('mmshub_vip_orders', JSON.stringify(vipOrders));
  }, [vipOrders]);

  useEffect(() => {
    localStorage.setItem('mmshub_vip_packages', JSON.stringify(vipPackages));
  }, [vipPackages]);

  useEffect(() => {
    localStorage.setItem('mmshub_sub_admins', JSON.stringify(subAdmins));
  }, [subAdmins]);

  useEffect(() => {
    localStorage.setItem('mmshub_custom_links', JSON.stringify(customSidebarLinks));
  }, [customSidebarLinks]);

  useEffect(() => {
    localStorage.setItem('mmshub_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('mmshub_ads', JSON.stringify(adSettings));
  }, [adSettings]);

  useEffect(() => {
    localStorage.setItem('mmshub_site_settings', JSON.stringify(siteSettings));
  }, [siteSettings]);

  useEffect(() => {
    localStorage.setItem('mmshub_stats', JSON.stringify(stats));
  }, [stats]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('mmshub_current_user', JSON.stringify(currentUser));
    }
  }, [currentUser]);

  // Anti-Copy & Context Menu protection
  useEffect(() => {
    if (!siteSettings.antiCopyEnabled) return;

    const handleContextMenu = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (isAdminLoggedIn || target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') {
        return;
      }
      e.preventDefault();
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        (e.ctrlKey && (e.key === 'u' || e.key === 'U')) ||
        (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i' || e.key === 'J' || e.key === 'j')) ||
        e.key === 'F12'
      ) {
        if (!isAdminLoggedIn) {
          e.preventDefault();
        }
      }
    };

    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [siteSettings.antiCopyEnabled, isAdminLoggedIn]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 3200);
  };

  const t = (key: keyof typeof TRANSLATIONS.en): string => {
    return TRANSLATIONS[language]?.[key] || TRANSLATIONS.en[key] || '';
  };

  // Video Management
  const addVideo = (newVidData: Omit<Video, 'id' | 'createdAt' | 'views' | 'likes' | 'dislikes'>) => {
    const newVideo: Video = {
      ...newVidData,
      id: `v-${Date.now()}`,
      createdAt: 'Just now',
      views: 1,
      likes: 1,
      dislikes: 0,
    };
    setVideos((prev) => [newVideo, ...prev]);
    setStats((prev) => ({
      ...prev,
      totalPosts: prev.totalPosts + 1,
      todayViews: prev.todayViews + 1,
      allTimeViews: prev.allTimeViews + 1,
    }));
    showToast('Video published successfully!');
  };

  const updateVideo = (id: string, updated: Partial<Video>) => {
    setVideos((prev) =>
      prev.map((vid) => (vid.id === id ? { ...vid, ...updated } : vid))
    );
    if (activeVideo && activeVideo.id === id) {
      setActiveVideo((prev) => (prev ? { ...prev, ...updated } : null));
    }
    showToast('Video updated successfully.');
  };

  const deleteVideo = (id: string) => {
    setVideos((prev) => prev.filter((vid) => vid.id !== id));
    if (activeVideo && activeVideo.id === id) {
      setActiveVideo(null);
    }
    setStats((prev) => ({ ...prev, totalPosts: Math.max(0, prev.totalPosts - 1) }));
    showToast('Video deleted.');
  };

  const incrementVideoView = (id: string) => {
    setVideos((prev) =>
      prev.map((vid) => (vid.id === id ? { ...vid, views: vid.views + 1 } : vid))
    );
    setStats((prev) => ({
      ...prev,
      todayViews: prev.todayViews + 1,
      allTimeViews: prev.allTimeViews + 1,
      thisMonthViews: prev.thisMonthViews + 1,
    }));
  };

  const likeVideo = (id: string) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }
    const isLiked = currentUser.likedVideoIds.includes(id);
    let updatedLikes: string[];

    if (isLiked) {
      updatedLikes = currentUser.likedVideoIds.filter((vId) => vId !== id);
      setVideos((prev) =>
        prev.map((v) => (v.id === id ? { ...v, likes: Math.max(0, v.likes - 1) } : v))
      );
      showToast('Removed like');
    } else {
      updatedLikes = [...currentUser.likedVideoIds, id];
      setVideos((prev) =>
        prev.map((v) => (v.id === id ? { ...v, likes: v.likes + 1 } : v))
      );
      showToast('Liked video ❤️');
    }

    const updatedUser = { ...currentUser, likedVideoIds: updatedLikes };
    setCurrentUser(updatedUser);
    setUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updatedUser : u)));
  };

  const dislikeVideo = (id: string) => {
    setVideos((prev) =>
      prev.map((v) => (v.id === id ? { ...v, dislikes: v.dislikes + 1 } : v))
    );
    showToast('Feedback submitted');
  };

  const toggleSaveVideo = (id: string) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }
    const isSaved = currentUser.savedVideoIds.includes(id);
    let newSaved: string[];
    if (isSaved) {
      newSaved = currentUser.savedVideoIds.filter((vId) => vId !== id);
      showToast('Removed from Saved Playlist');
    } else {
      newSaved = [...currentUser.savedVideoIds, id];
      showToast('Saved to Playlist 📁');
    }
    const updatedUser = { ...currentUser, savedVideoIds: newSaved };
    setCurrentUser(updatedUser);
    setUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updatedUser : u)));
  };

  // Comments (Max 3 comments per user per video)
  const addComment = (videoId: string, text: string): boolean => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return false;
    }

    const userCommentsOnThisVid = comments.filter(
      (c) => c.videoId === videoId && c.userId === currentUser.id
    );

    if (userCommentsOnThisVid.length >= 3 && currentUser.role !== 'admin') {
      showToast('You can only post up to 3 comments on this video!');
      return false;
    }

    const newComment: Comment = {
      id: `c-${Date.now()}`,
      videoId,
      userId: currentUser.id,
      userName: currentUser.username,
      userAvatar: currentUser.avatar,
      text: text.trim(),
      createdAt: 'Just now',
    };

    setComments((prev) => [newComment, ...prev]);
    setStats((prev) => ({ ...prev, totalComments: prev.totalComments + 1 }));
    showToast('Comment posted! 👍');
    return true;
  };

  const deleteComment = (commentId: string) => {
    setComments((prev) => prev.filter((c) => c.id !== commentId));
    setStats((prev) => ({ ...prev, totalComments: Math.max(0, prev.totalComments - 1) }));
    showToast('Comment removed.');
  };

  // VIP & Payments
  const submitVipOrder = (orderData: {
    userPhone: string;
    packageType: '1 Month' | '3 Months' | '6 Months' | '1 Year';
    priceBdt: number;
    gateway: 'bkash' | 'nagad' | 'rocket';
    trxId: string;
  }) => {
    const newOrder: VipOrder = {
      id: `ord-${Date.now()}`,
      userId: currentUser ? currentUser.id : 'guest',
      userName: currentUser ? currentUser.username : 'Guest User',
      userPhone: orderData.userPhone,
      packageType: orderData.packageType,
      priceBdt: orderData.priceBdt,
      gateway: orderData.gateway,
      trxId: orderData.trxId.toUpperCase(),
      status: 'pending',
      createdAt: new Date().toLocaleString(),
    };

    setVipOrders((prev) => [newOrder, ...prev]);
    showToast('Payment submitted! Admin will verify and activate your VIP shortly.');
  };

  const approveVipOrder = (orderId: string) => {
    const order = vipOrders.find((o) => o.id === orderId);
    if (!order) return;

    setVipOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: 'approved' } : o))
    );

    setStats((prev) => ({
      ...prev,
      totalEarningsBdt: prev.totalEarningsBdt + order.priceBdt,
    }));

    // Grant VIP status to user
    setUsers((prev) =>
      prev.map((u) =>
        u.id === order.userId || u.username === order.userName
          ? { ...u, isVip: true, vipExpiresAt: '30 Days' }
          : u
      )
    );

    if (currentUser && (currentUser.id === order.userId || currentUser.username === order.userName)) {
      setCurrentUser({
        ...currentUser,
        isVip: true,
        vipExpiresAt: '30 Days',
      });
    }

    showToast(`Order approved! ৳${order.priceBdt} added to wallet.`);
  };

  const rejectVipOrder = (orderId: string) => {
    setVipOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: 'rejected' } : o))
    );
    showToast('Order marked as rejected.');
  };

  const updateVipPackagePrice = (
    id: '1 Month' | '3 Months' | '6 Months' | '1 Year',
    newPrice: number
  ) => {
    setVipPackages((prev) =>
      prev.map((p) => (p.id === id ? { ...p, priceBdt: newPrice } : p))
    );
    showToast(`Price for ${id} updated to ৳${newPrice}`);
  };

  // Sub-Admins Management (Limit: 1 superadmin + max 2 sub-admins = 3 total)
  const addSubAdmin = (newAdminData: Omit<SubAdmin, 'id' | 'createdAt'>): boolean => {
    if (subAdmins.length >= 2) {
      showToast('Maximum 3 admins reached (1 Superadmin + 2 Sub-admins)!');
      return false;
    }
    const newAdmin: SubAdmin = {
      ...newAdminData,
      id: `sub-${Date.now()}`,
      createdAt: new Date().toLocaleString(),
    };
    setSubAdmins((prev) => [...prev, newAdmin]);
    showToast(`Sub-admin ${newAdmin.username} added successfully!`);
    return true;
  };

  const removeSubAdmin = (id: string) => {
    setSubAdmins((prev) => prev.filter((a) => a.id !== id));
    showToast('Sub-admin removed.');
  };

  // Custom Sidebar Links
  const addCustomSidebarLink = (linkData: Omit<CustomSidebarLink, 'id'>) => {
    const newLink: CustomSidebarLink = {
      ...linkData,
      id: `link-${Date.now()}`,
    };
    setCustomSidebarLinks((prev) => [...prev, newLink]);
    showToast('Custom sidebar link added!');
  };

  const deleteCustomSidebarLink = (id: string) => {
    setCustomSidebarLinks((prev) => prev.filter((l) => l.id !== id));
    showToast('Sidebar link removed.');
  };

  // User Authentication & Management
  const registerOrLoginUser = (username: string, password?: string) => {
    const trimmedUser = username.trim();
    const existing = users.find(
      (u) => u.username.toLowerCase() === trimmedUser.toLowerCase()
    );

    const now = new Date().toLocaleString();

    if (existing) {
      const updatedUser: User = {
        ...existing,
        lastLoginAt: now,
      };
      setUsers((prev) => prev.map((u) => (u.id === existing.id ? updatedUser : u)));
      setCurrentUser(updatedUser);
      setIsAuthModalOpen(false);
      showToast(`Welcome back, ${updatedUser.username}!`);
    } else {
      // Pick random adult star avatar preset
      const randomAvatar =
        ADULT_STAR_AVATARS[Math.floor(Math.random() * ADULT_STAR_AVATARS.length)];

      const newUser: User = {
        id: `u-${Date.now()}`,
        username: trimmedUser,
        password: password || '123456',
        email: `${trimmedUser.toLowerCase()}@user.tube`,
        avatar: randomAvatar,
        isVip: false,
        savedVideoIds: [],
        likedVideoIds: [],
        role: 'user',
        createdAt: now,
        lastLoginAt: now,
      };

      setUsers((prev) => [newUser, ...prev]);
      setCurrentUser(newUser);
      setStats((prev) => ({ ...prev, totalFollowers: prev.totalFollowers + 1 }));
      setIsAuthModalOpen(false);
      showToast(`Account created for ${newUser.username}!`);
    }
  };

  const logoutUser = () => {
    setCurrentUser(null);
    showToast('Logged out.');
  };

  // Constraint: Username can be changed only once every 30 days
  const changeUsername = (newUsername: string): { success: boolean; message: string } => {
    if (!currentUser) return { success: false, message: 'Not logged in' };
    const trimmed = newUsername.trim();
    if (!trimmed || trimmed.length < 3) {
      return { success: false, message: 'Username must be at least 3 characters' };
    }

    if (currentUser.lastUsernameChangeAt) {
      const lastChange = new Date(currentUser.lastUsernameChangeAt).getTime();
      const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;
      if (Date.now() - lastChange < thirtyDaysMs) {
        const daysLeft = Math.ceil((thirtyDaysMs - (Date.now() - lastChange)) / (1000 * 60 * 60 * 24));
        return {
          success: false,
          message: `Username can be changed once every 30 days. Please wait ${daysLeft} more days.`,
        };
      }
    }

    const updated: User = {
      ...currentUser,
      username: trimmed,
      lastUsernameChangeAt: new Date().toISOString(),
    };
    setCurrentUser(updated);
    setUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
    return { success: true, message: 'Username updated successfully!' };
  };

  // Constraint: Password change requires correct old password
  const changePassword = (oldPass: string, newPass: string): { success: boolean; message: string } => {
    if (!currentUser) return { success: false, message: 'Not logged in' };
    if (currentUser.password && currentUser.password !== oldPass) {
      return { success: false, message: 'Previous password does not match!' };
    }
    if (newPass.length < 4) {
      return { success: false, message: 'Password must be at least 4 characters' };
    }

    const updated: User = { ...currentUser, password: newPass };
    setCurrentUser(updated);
    setUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
    return { success: true, message: 'Password changed successfully!' };
  };

  // Constraint: Profile pic change restricted for 7 days
  const changeAvatar = (newAvatarUrl: string): { success: boolean; message: string } => {
    if (!currentUser) return { success: false, message: 'Not logged in' };

    if (currentUser.lastAvatarChangeAt) {
      const lastChange = new Date(currentUser.lastAvatarChangeAt).getTime();
      const sevenDaysMs = 7 * 24 * 60 * 60 * 1000;
      if (Date.now() - lastChange < sevenDaysMs) {
        const daysLeft = Math.ceil((sevenDaysMs - (Date.now() - lastChange)) / (1000 * 60 * 60 * 24));
        return {
          success: false,
          message: `Profile photo can be changed once every 7 days. Please wait ${daysLeft} more days.`,
        };
      }
    }

    const updated: User = {
      ...currentUser,
      avatar: newAvatarUrl,
      lastAvatarChangeAt: new Date().toISOString(),
    };
    setCurrentUser(updated);
    setUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
    return { success: true, message: 'Profile photo updated!' };
  };

  const updateUserByAdmin = (userId: string, updated: Partial<User>) => {
    setUsers((prev) => prev.map((u) => (u.id === userId ? { ...u, ...updated } : u)));
    if (currentUser && currentUser.id === userId) {
      setCurrentUser((prev) => (prev ? { ...prev, ...updated } : null));
    }
    showToast('User profile updated by admin.');
  };

  const deleteUserByAdmin = (userId: string) => {
    setUsers((prev) => prev.filter((u) => u.id !== userId));
    showToast('User account deleted.');
  };

  // Strict Admin Login (Requires verification against main admin or sub-admins)
  const loginAdmin = (user: string, pass: string): boolean => {
    const trimmedUser = user.trim();
    const trimmedPass = pass.trim();

    // Check main superadmin
    if (
      trimmedUser === siteSettings.adminUsername &&
      trimmedPass === siteSettings.adminPasswordHash
    ) {
      setIsAdminLoggedIn(true);
      setLoggedInAdminRole('superadmin');
      showToast('Super-Admin authenticated! 👑');
      return true;
    }

    // Check sub-admins
    const sub = subAdmins.find(
      (s) => s.username === trimmedUser && s.passwordHash === trimmedPass
    );
    if (sub) {
      setIsAdminLoggedIn(true);
      setLoggedInAdminRole('subadmin');
      showToast(`Sub-Admin authenticated (${sub.name})! 🛡️`);
      return true;
    }

    showToast('Invalid admin username or password!');
    return false;
  };

  const logoutAdmin = () => {
    setIsAdminLoggedIn(false);
    setLoggedInAdminRole(null);
    showToast('Admin logged out.');
  };

  const updateAdSettings = (newAds: Partial<AdSettings>) => {
    setAdSettings((prev) => ({ ...prev, ...newAds }));
    showToast('Ad settings saved.');
  };

  const updateSiteSettings = (newSettings: Partial<SiteSettings>) => {
    setSiteSettings((prev) => ({ ...prev, ...newSettings }));
    showToast('Site settings updated.');
  };

  const addCategory = (name: string, slug: string) => {
    const newCat: Category = {
      id: slug.toLowerCase().replace(/\s+/g, '-'),
      name,
      slug: slug.toLowerCase().replace(/\s+/g, '-'),
      count: 0,
    };
    setBaseCategories((prev) => [...prev, newCat]);
    showToast('Category added!');
  };

  const deleteCategory = (id: string) => {
    setBaseCategories((prev) => prev.filter((c) => c.id !== id));
    showToast('Category deleted.');
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        isNightMode,
        setIsNightMode,

        videos,
        categories,
        comments,
        vipOrders,
        adSettings,
        siteSettings,
        stats,
        currentUser,
        activeVideo,
        searchQuery,
        selectedCategory,
        pricingFilter,
        isAgeGatePassed,

        subAdmins,
        customSidebarLinks,
        vipPackages,
        users,

        isSidebarOpen,
        isAdminOpen,
        isAdminLoggedIn,
        loggedInAdminRole,
        isAuthModalOpen,
        isVipModalOpen,
        isSettingsModalOpen,
        isGuideModalOpen,
        toastMessage,

        setActiveVideo,
        setSearchQuery,
        setSelectedCategory,
        setPricingFilter,
        setIsAgeGatePassed: (val) => {
          setIsAgeGatePassed(val);
          localStorage.setItem('mmshub_age_gate', val ? 'passed' : '');
        },
        setIsSidebarOpen,
        setIsAdminOpen,
        setIsAuthModalOpen,
        setIsVipModalOpen,
        setIsSettingsModalOpen,
        setIsGuideModalOpen,
        showToast,

        addVideo,
        updateVideo,
        deleteVideo,
        incrementVideoView,
        likeVideo,
        dislikeVideo,
        toggleSaveVideo,

        addComment,
        deleteComment,

        submitVipOrder,
        approveVipOrder,
        rejectVipOrder,
        updateVipPackagePrice,

        updateAdSettings,
        updateSiteSettings,

        addCategory,
        deleteCategory,

        addSubAdmin,
        removeSubAdmin,

        addCustomSidebarLink,
        deleteCustomSidebarLink,

        registerOrLoginUser,
        logoutUser,
        changeUsername,
        changePassword,
        changeAvatar,
        updateUserByAdmin,
        deleteUserByAdmin,

        loginAdmin,
        logoutAdmin,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
