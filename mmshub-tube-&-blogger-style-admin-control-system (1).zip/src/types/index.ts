export interface Video {
  id: string;
  title: string;
  description: string;
  thumbnailUrl: string;
  embedCode: string; // iframe code or direct URL
  category: string;
  tags: string[];
  duration: string;
  views: number;
  likes: number;
  dislikes: number;
  createdAt: string;
  author: string;
  isVip: boolean;
  downloadUrl?: string;
  quality?: 'HD' | '4K' | 'SD';
}

export interface Comment {
  id: string;
  videoId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  text: string;
  createdAt: string;
  replyToId?: string;
  replies?: Comment[];
}

export interface User {
  id: string;
  username: string;
  password?: string;
  email?: string;
  avatar: string;
  isVip: boolean;
  vipExpiresAt?: string;
  savedVideoIds: string[];
  likedVideoIds: string[];
  role: 'user' | 'admin' | 'subadmin';
  createdAt: string;
  lastLoginAt: string;
  lastUsernameChangeAt?: string; // 30 day limit
  lastAvatarChangeAt?: string;   // 7 day limit
}

export interface SubAdmin {
  id: string;
  username: string;
  passwordHash: string;
  name: string;
  email: string;
  createdAt: string;
}

export interface CustomSidebarLink {
  id: string;
  title: string;
  url: string;
  badge?: string;
  openNewTab: boolean;
}

export interface VipPackage {
  id: '1 Month' | '3 Months' | '6 Months' | '1 Year';
  title: string;
  priceBdt: number;
  badge: string | null;
  desc: string;
}

export interface VipOrder {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  packageType: '1 Month' | '3 Months' | '6 Months' | '1 Year';
  priceBdt: number;
  gateway: 'bkash' | 'nagad' | 'rocket';
  trxId: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  count: number;
  icon?: string;
}

export interface AdSettings {
  topBannerEnabled: boolean;
  topBannerHtml: string;
  topBannerLink: string;
  topBannerImage: string;
  nativeBarEnabled: boolean;
  socialBarEnabled: boolean;
  smartLink1: string;
  smartLink2: string;
  smartLink3: string;
  directDownloadLink: string;
}

export interface SiteSettings {
  siteTitle: string;
  siteLogoText: string;
  siteNotice: string;
  antiCopyEnabled: boolean;
  ageGateEnabled: boolean;
  adminUsername: string;
  adminPasswordHash: string;
  bkashNumber: string;
  nagadNumber: string;
  rocketNumber: string;
}

export interface SiteStats {
  allTimeViews: number;
  todayViews: number;
  yesterdayViews: number;
  thisMonthViews: number;
  lastMonthViews: number;
  totalPosts: number;
  totalComments: number;
  totalFollowers: number;
  totalEarningsBdt: number;
  dailyViewsChart: { day: string; views: number }[];
}
